# Weather Dest

## File

* [`weatherdest.js`](weatherdest.js)

## Instructions

* Take a moment to run the `weatherdest.js` application. (Try to figure out what it takes to run on your own!)

* Then, with a partner, spend a few moments answering the following questions:

  * What does the code do?

  * How does it work at a general level?

  * How does it work at a line level?
